# El Farol Bar Problem experimental setup in PsyNet

An implementation as a behavioral experiment of the El Farol Bar Problem using the [PsyNet framework](https://www.psynet.dev/).

For installation instructions, see docs/INSTALL.md.

For a list of run commands, see docs/RUN.md.

For more information about PsyNet, see the [documentation website](https://psynetdev.gitlab.io/PsyNet/).
